const { chromium } = require('playwright');
const path = require('path');

(async () => {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    const errors = [];
    const warnings = [];

    // Collect console messages
    page.on('console', msg => {
        if (msg.type() === 'error') {
            errors.push(msg.text());
        } else if (msg.type() === 'warning') {
            warnings.push(msg.text());
        }
    });

    // Collect page errors
    page.on('pageerror', err => {
        errors.push(err.message);
    });

    try {
        const filePath = path.join(__dirname, 'index.html');
        await page.goto(`file://${filePath}`, { waitUntil: 'networkidle' });

        // Wait for animations to settle
        await page.waitForTimeout(2000);

        // Check page loaded
        const title = await page.title();
        console.log('Page Title:', title);

        // Check hero section exists
        const heroExists = await page.$('#hero');
        console.log('Hero Section:', heroExists ? 'Found' : 'Not Found');

        // Check navigation exists
        const navExists = await page.$('.nav-dock');
        console.log('Navigation Dock:', navExists ? 'Found' : 'Not Found');

        // Check projects section
        const projectsExist = await page.$('#projects');
        console.log('Projects Section:', projectsExist ? 'Found' : 'Not Found');

        // Check contact section
        const contactExists = await page.$('#contact');
        console.log('Contact Section:', contactExists ? 'Found' : 'Not Found');

        // Report errors
        if (errors.length > 0) {
            console.log('\n=== Console Errors ===');
            errors.forEach(err => console.log('ERROR:', err));
        } else {
            console.log('\nNo console errors detected!');
        }

        if (warnings.length > 0) {
            console.log('\n=== Console Warnings ===');
            warnings.forEach(warn => console.log('WARNING:', warn));
        }

        console.log('\n=== Test Complete ===');
        console.log('Status:', errors.length === 0 ? 'PASSED' : 'FAILED');

    } catch (err) {
        console.error('Test failed:', err.message);
    } finally {
        await browser.close();
    }
})();
